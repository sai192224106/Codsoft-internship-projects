// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', e => {
    const target = document.querySelector(link.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth' });
    }
    // Close mobile menu
    const navUl = document.getElementById('nav-links');
    if (navUl.classList.contains('show')) {
      navUl.classList.remove('show');
    }
  });
});

// Active link on scroll & section show animation
const sections = document.querySelectorAll('section');
const navLinks = document.querySelectorAll('nav ul li a');

window.addEventListener('scroll', () => {
  let current = '';
  sections.forEach(section => {
    const sectionTop = section.offsetTop - 180;
    if (pageYOffset >= sectionTop) {
      current = section.getAttribute('id');
    }

    // Section fade-in
    if (window.pageYOffset + window.innerHeight > section.offsetTop + 50) {
      section.classList.add('show');
    }
  });

  navLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href') === `#${current}`) {
      link.classList.add('active');
    }
  });

  // Animate skills
  showSkills();

  // Animate project cards
  showProjects();
});

// Hamburger menu toggle
const menuToggle = document.getElementById('menu-toggle');
const navUl = document.getElementById('nav-links');
menuToggle.addEventListener('click', () => {
  navUl.classList.toggle('show');
});

// Skills animation
const skills = document.querySelectorAll('ul.skills-grid li');
function showSkills() {
  skills.forEach((skill, index) => {
    const skillTop = skill.getBoundingClientRect().top;
    const windowHeight = window.innerHeight;
    if (skillTop < windowHeight - 50) {
      setTimeout(() => {
        skill.classList.add('show');
      }, index * 150);
    }
  });
}

// Project cards animation
const projects = document.querySelectorAll('.project-card');
function showProjects() {
  projects.forEach((project, index) => {
    const projectTop = project.getBoundingClientRect().top;
    const windowHeight = window.innerHeight;
    if (projectTop < windowHeight - 50) {
      setTimeout(() => {
        project.classList.add('show');
      }, index * 150);
    }
  });
}

// Initial animations on load
window.addEventListener('load', () => {
  sections.forEach(section => {
    if (window.pageYOffset + window.innerHeight > section.offsetTop + 50) {
      section.classList.add('show');
    }
  });
  showSkills();
  showProjects();
});
