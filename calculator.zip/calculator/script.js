const display = document.getElementById("display");
const buttons = document.querySelectorAll(".btn");
const clear = document.getElementById("clear");
const equals = document.getElementById("equals");

let input = "";

// Add event listeners for all buttons
buttons.forEach(button => {
  button.addEventListener("click", () => {
    input += button.getAttribute("data-value");
    display.value = input;
  });
});

// Clear the display
clear.addEventListener("click", () => {
  input = "";
  display.value = "";
});

// Evaluate the expression
equals.addEventListener("click", () => {
  try {
    input = eval(input).toString();
    display.value = input;
  } catch {
    display.value = "Error";
    input = "";
  }
});
